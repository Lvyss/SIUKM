






<dialog id="eventModal" 
    class="bg-white rounded-2xl shadow-2xl p-0 w-full max-w-lg md:max-w-5xl max-h-[95vh] md:max-h-[90vh] 
        backdrop:bg-black/40 backdrop:backdrop-blur-sm 
        transform transition-all duration-300 opacity-0 scale-95 flex flex-col overflow-hidden">
    
    <div class="relative flex flex-col md:flex-row h-full">
        
        
        <div class="w-full md:w-5/12 flex-shrink-0 bg-gray-100 relative rounded-t-2xl md:rounded-l-none md:rounded-r-2xl overflow-hidden shadow-inner flex items-center justify-center h-64 sm:h-80 md:h-auto">
            
            <div id="modalPoster" class="w-full h-full">
                
            </div>
            
            
            <button id="closeEventModal"
                class="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/70 backdrop-blur-sm hover:bg-white flex items-center justify-center transition-colors shadow-lg border border-gray-100">
                <i class="fas fa-times text-gray-600 text-lg"></i>
            </button>
            
            
            <div class="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/50 to-transparent flex justify-center">
                <button onclick="/* Logika pendaftaran event */"
                        class="px-8 py-2.5 bg-orange-600 text-white rounded-full hover:bg-orange-700 font-medium transition-colors shadow-xl">
                    <i class="fas fa-ticket-alt mr-2 text-sm"></i> Daftar Sekarang!
                </button>
            </div>
        </div>
        
        
        <div class="w-full md:w-7/12 flex-shrink-0 p-5 sm:p-8 overflow-y-auto max-h-[60vh] md:max-h-[90vh] pb-8 md:pb-20">

            <h1 class="text-2xl sm:text-4xl font-extrabold text-gray-900 mb-4 leading-tight" id="modalTitle">Judul Event</h1>
            
            <div class="mb-6 md:mb-8 p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-2">
                
                <div class="flex items-center text-sm sm:text-base font-semibold text-gray-700">
                    <i class="fas fa-users mr-3 text-blue-600 w-4"></i>
                    <span id="modalUkm" class="font-bold text-blue-600">Nama UKM (Organizer)</span>
                </div>
                
                <div class="space-y-2 pt-2 border-t border-gray-200">
                    <div class="flex items-center text-xs sm:text-sm text-gray-600">
                        <i class="fas fa-calendar-alt mr-3 text-blue-500 w-4"></i>
                        <span id="modalDate">Tanggal Event</span>
                    </div>
                    
                    <div class="flex items-center text-xs sm:text-sm text-gray-600">
                        <i class="fas fa-clock mr-3 text-green-500 w-4"></i>
                        <span id="modalTime">Waktu Event</span>
                    </div>

                    <div class="flex items-start text-xs sm:text-sm text-gray-600">
                        <i class="fas fa-map-marker-alt mr-3 text-red-500 mt-1 w-4"></i>
                        <span id="modalLocation" class="font-medium">Lokasi Event</span>
                    </div>
                </div>
            </div>
            
            <div class="prose max-w-none text-gray-700 leading-relaxed text-sm sm:text-base">
                <h2 class="text-xl sm:text-2xl font-bold text-gray-800 mb-3">Deskripsi Kegiatan</h2>
                <p id="modalDescription" class="whitespace-pre-line">
                    
                </p>
            </div>
        </div>
    </div>
</dialog>





<dialog id="feedModal" 
    class="bg-white rounded-2xl shadow-2xl p-0 w-full max-w-lg md:max-w-5xl max-h-[95vh] md:max-h-[90vh]
        backdrop:bg-black/40 backdrop:backdrop-blur-sm 
        transform transition-all duration-300 opacity-0 scale-95 flex flex-col overflow-hidden">
    
    <div class="relative flex flex-col md:flex-row h-full">
        
        
        <div class="w-full md:w-5/12 flex-shrink-0 bg-gray-100 relative rounded-t-2xl md:rounded-l-none md:rounded-r-2xl overflow-hidden shadow-inner flex items-center justify-center h-64 sm:h-80 md:h-auto">
            
            <div id="feedModalImage" class="w-full h-full">
                
            </div>
            
            
            <button id="closeFeedModal"
                class="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/70 backdrop-blur-sm hover:bg-white flex items-center justify-center transition-colors shadow-lg border border-gray-100">
                <i class="fas fa-times text-gray-600 text-lg"></i>
            </button>
            
            
            <div class="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/50 to-transparent flex justify-center">
                <button onclick="document.getElementById('feedModal').close()"
                        class="px-8 py-2.5 bg-white/90 text-gray-800 rounded-full hover:bg-white font-medium transition-colors shadow-xl">
                    <i class="fas fa-chevron-circle-up rotate-180 mr-2 text-sm"></i> Tutup Detail
                </button>
            </div>
        </div>
        
        
        <div class="w-full md:w-7/12 flex-shrink-0 p-5 sm:p-8 overflow-y-auto max-h-[60vh] md:max-h-[90vh] pb-8 md:pb-20">

            <h1 class="text-2xl sm:text-4xl font-extrabold text-gray-900 mb-4 leading-tight" id="feedModalTitle">Judul Feed</h1>
            
            <div class="mb-6 md:mb-8 p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-2">
                
                <div class="flex items-center text-sm sm:text-base font-semibold text-gray-700">
                    <i class="fas fa-users mr-3 text-blue-600 w-4"></i>
                    <span id="feedModalUkm" class="font-bold text-blue-600">Nama UKM</span>
                </div>
                
                <div class="space-y-2 pt-2 border-t border-gray-200">
                    <div class="flex items-center text-xs sm:text-sm text-gray-600">
                        <i class="fas fa-calendar-alt mr-3 text-blue-500 w-4"></i>
                        <span id="feedModalDate">Tanggal Posting</span>
                    </div>
                    
                    <div class="flex items-center text-xs sm:text-sm text-gray-600">
                        <i class="far fa-eye mr-3 text-red-500 w-4"></i>
                        <span id="feedModalViews">Jumlah Dilihat</span>
                    </div>
                </div>
            </div>
            
            <div class="prose max-w-none text-gray-700 leading-relaxed text-sm sm:text-base">
                <h2 class="text-xl sm:text-2xl font-bold text-gray-800 mb-3">Isi Konten</h2>
                <p id="feedModalContent" class="whitespace-pre-line">
                    
                </p>
            </div>
            
        </div>
        
    </div>
</dialog>






<script>
    document.addEventListener('DOMContentLoaded', function() {
        const eventModal = document.getElementById('eventModal');
        const feedModal = document.getElementById('feedModal');

        // --- A. FUNGSI PENUTUP MODAL (untuk tombol X dan transisi) ---
        function setupModalClose(modalId, closeBtnId) {
            const modal = document.getElementById(modalId);
            const closeBtn = document.getElementById(closeBtnId);

            if (modal && closeBtn) {
                closeBtn.addEventListener('click', (e) => {
                    e.preventDefault(); 
                    // Terapkan transisi keluar (Tailwind classes)
                    modal.classList.add('opacity-0', 'scale-95');
                    setTimeout(() => {
                        modal.close();
                        // Reset classes setelah menutup agar siap dibuka lagi
                        modal.classList.remove('opacity-0', 'scale-95'); 
                    }, 300); // Durasi harus sesuai dengan durasi CSS transition
                });
            }
        }

        // Setup tombol X untuk kedua modal (Fix yang Feed ada di sini)
        setupModalClose('eventModal', 'closeEventModal'); 
        setupModalClose('feedModal', 'closeFeedModal');   

        // --- B. FUNGSI PEMBUKA DAN PENGISI MODAL EVENT ---
        document.querySelectorAll('.event-card').forEach(card => {
            card.addEventListener('click', function() {
                const data = this.dataset;

                document.getElementById('modalTitle').textContent = data.eventTitle;
                document.getElementById('modalUkm').textContent = data.eventUkm;
                document.getElementById('modalDate').textContent = data.eventDate;
                document.getElementById('modalTime').textContent = data.eventTime;
                document.getElementById('modalLocation').textContent = data.eventLocation;
                document.getElementById('modalDescription').textContent = data.eventDescription;
                
                // Isi Poster
                const posterContainer = document.getElementById('modalPoster');
                posterContainer.innerHTML = ''; 
                if (data.eventPoster) {
                    posterContainer.innerHTML = `<img src="${data.eventPoster}" alt="${data.eventTitle}" class="w-full h-full object-cover">`;
                } else {
                    posterContainer.innerHTML = `<div class="w-full h-full bg-gray-200 flex items-center justify-center"><i class="fas fa-calendar-check text-4xl text-gray-500"></i></div>`;
                }

                eventModal.showModal();
            });
        });

        // --- C. FUNGSI PEMBUKA DAN PENGISI MODAL FEED ---
        document.querySelectorAll('.feed-card').forEach(card => {
            card.addEventListener('click', function() {
                const data = this.dataset;

                document.getElementById('feedModalTitle').textContent = data.feedTitle;
                document.getElementById('feedModalUkm').textContent = data.feedUkm;
                document.getElementById('feedModalDate').textContent = data.feedCreated;
                document.getElementById('feedModalViews').textContent = data.feedViews; 
                document.getElementById('feedModalContent').textContent = data.feedContent;
                
                // Isi Gambar Feed
                const imageContainer = document.getElementById('feedModalImage');
                imageContainer.innerHTML = ''; 
                if (data.feedImage) {
                    imageContainer.innerHTML = `<img src="${data.feedImage}" alt="${data.feedTitle}" class="w-full h-full object-cover">`;
                } else {
                    imageContainer.innerHTML = `<div class="w-full h-full bg-gray-200 flex items-center justify-center"><i class="fas fa-image text-4xl text-gray-500"></i></div>`;
                }

                feedModal.showModal();
            });
        });
    });
</script>


<?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/partials/_modals_and_scripts.blade.php ENDPATH**/ ?>