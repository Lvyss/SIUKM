

<?php $__env->startSection('content'); ?>
<style>
    /* CUSTOM STYLES LUXURY SAMA KAYA USER MANAGEMENT */
    .lux-bg { background-color: #f3f4f6; }
    .lux-gold-text { color: #b45309; } 

    .floating-card {
        background-color: white;
        border-radius: 12px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        border: 1px solid #e5e7eb;
    }
    .floating-card:hover {
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        transform: translateY(-2px);
    }
    
    .lux-button {
        background-color: #b45309;
        color: white;
        transition: background-color 0.2s;
    }
    .lux-button:hover {
        background-color: #92400e;
    }
    
    .input-lux:focus {
        border-color: #b45309;
        box-shadow: 0 0 0 2px rgba(180, 83, 9, 0.4);
    }

    dialog.modal-lux::backdrop {
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(2px);
    }
    dialog.modal-lux {
        animation: fadeIn 0.3s ease-out;
        border: none;
        padding: 0;
        border-radius: 12px;
        width: 95vw;
        max-width: 28rem;
        margin: 1rem auto;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
    }
    
    .hover-row-table:hover {
        background-color: #fffaf0;
    }
</style>

<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
    <h1 class="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">Event Matrix & Management</h1>
    <div class="text-sm font-semibold lux-gold-text px-3 py-1 rounded-full border border-gray-300 bg-amber-50 whitespace-nowrap">
        <i class="fas fa-calendar-alt mr-1 lux-gold-text"></i> Total: **<?php echo e($events->total()); ?> events**
    </div>
</div>

<!-- Statistics Cards -->
<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 mb-6">
    <div class="floating-card p-3 sm:p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-blue-100 flex-shrink-0">
                <i class="fas fa-calendar-alt text-blue-600 text-sm"></i>
            </div>
            <div class="ml-3 min-w-0">
                <p class="text-xs sm:text-sm font-medium text-gray-600 truncate">Total</p>
                <p class="text-lg sm:text-xl font-bold text-gray-900"><?php echo e($totalEvents); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-3 sm:p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-green-100 flex-shrink-0">
                <i class="fas fa-rocket text-green-600 text-sm"></i>
            </div>
            <div class="ml-3 min-w-0">
                <p class="text-xs sm:text-sm font-medium text-gray-600 truncate">Upcoming</p>
                <p class="text-lg sm:text-xl font-bold text-gray-900"><?php echo e($upcomingEvents); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-3 sm:p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-gray-100 flex-shrink-0">
                <i class="fas fa-history text-gray-600 text-sm"></i>
            </div>
            <div class="ml-3 min-w-0">
                <p class="text-xs sm:text-sm font-medium text-gray-600 truncate">Past</p>
                <p class="text-lg sm:text-xl font-bold text-gray-900"><?php echo e($pastEvents); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-3 sm:p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-purple-100 flex-shrink-0">
                <i class="fas fa-star text-purple-600 text-sm"></i>
            </div>
            <div class="ml-3 min-w-0">
                <p class="text-xs sm:text-sm font-medium text-gray-600 truncate">Today</p>
                <p class="text-lg sm:text-xl font-bold text-gray-900"><?php echo e($todayEvents); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-3 sm:p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-orange-100 flex-shrink-0">
                <i class="fas fa-image text-orange-600 text-sm"></i>
            </div>
            <div class="ml-3 min-w-0">
                <p class="text-xs sm:text-sm font-medium text-gray-600 truncate">With Posters</p>
                <p class="text-lg sm:text-xl font-bold text-gray-900"><?php echo e($eventsWithPosters); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Filters & Search -->
<div class="floating-card mb-6">
    <div class="p-4 sm:p-5 border-b border-gray-100">
        <h2 class="text-lg font-bold text-gray-800 flex items-center">
            <i class="fas fa-filter mr-2 lux-gold-text"></i> Search & Filters
        </h2>
    </div>
    <div class="p-4 sm:p-5">
        <form action="<?php echo e(route('admin.events.index')); ?>" method="GET" class="space-y-4 sm:space-y-0 sm:flex sm:flex-row sm:items-end sm:gap-3">
            <div class="flex-1 sm:flex-[2]">
                <label class="block text-xs font-semibold text-gray-600 uppercase mb-1">Search Events</label>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                       placeholder="Title, description, location..."
                       class="w-full border border-gray-300 rounded-lg px-4 py-2 input-lux:focus transition duration-150 text-sm sm:text-base">
            </div>
            
            <div class="sm:min-w-[140px]">
                <label class="block text-xs font-semibold text-gray-600 uppercase mb-1">UKM</label>
                <select name="ukm_id" class="w-full border border-gray-300 rounded-lg px-4 py-2 input-lux:focus transition duration-150 text-sm sm:text-base">
                    <option value="">All UKM</option>
                    <?php $__currentLoopData = $ukms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ukm->id); ?>" <?php echo e(request('ukm_id') == $ukm->id ? 'selected' : ''); ?>>
                            <?php echo e($ukm->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="sm:min-w-[140px]">
                <label class="block text-xs font-semibold text-gray-600 uppercase mb-1">Date Filter</label>
                <select name="date_filter" class="w-full border border-gray-300 rounded-lg px-4 py-2 input-lux:focus transition duration-150 text-sm sm:text-base">
                    <option value="">All Dates</option>
                    <option value="today" <?php echo e(request('date_filter') == 'today' ? 'selected' : ''); ?>>Today</option>
                    <option value="upcoming" <?php echo e(request('date_filter') == 'upcoming' ? 'selected' : ''); ?>>Upcoming</option>
                    <option value="past" <?php echo e(request('date_filter') == 'past' ? 'selected' : ''); ?>>Past</option>
                    <option value="this_week" <?php echo e(request('date_filter') == 'this_week' ? 'selected' : ''); ?>>This Week</option>
                    <option value="this_month" <?php echo e(request('date_filter') == 'this_month' ? 'selected' : ''); ?>>This Month</option>
                </select>
            </div>
            
            <div class="flex flex-col sm:flex-row sm:items-end sm:space-x-2 space-y-2 sm:space-y-0 pt-2 sm:pt-0">
                <button type="submit" 
                        class="lux-button px-4 py-2 rounded-lg hover:bg-amber-700 transition duration-200 flex items-center justify-center text-sm sm:text-base h-[42px] sm:h-auto">
                    <i class="fas fa-search mr-2"></i> Search
                </button>
                <a href="<?php echo e(route('admin.events.index')); ?>" 
                   class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition duration-200 flex items-center justify-center text-sm sm:text-base h-[42px] sm:h-auto">
                    <i class="fas fa-refresh mr-2"></i> Reset
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Events Table -->
<div class="floating-card overflow-hidden">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 border-b bg-gray-50/50 gap-4">
        <h2 class="text-lg font-bold text-gray-800 flex items-center">
            <i class="fas fa-database mr-2 lux-gold-text"></i>
            <?php if(request('ukm_id')): ?>
                <?php
                    $selectedUkm = $ukms->where('id', request('ukm_id'))->first();
                ?>
                Events - <?php echo e($selectedUkm->name ?? 'Selected UKM'); ?>

            <?php elseif(request('date_filter')): ?>
                <?php echo e(ucfirst(str_replace('_', ' ', request('date_filter')))); ?> Events
            <?php else: ?>
                All Events
            <?php endif; ?>
        </h2>
        
        <div class="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 w-full sm:w-auto">
            <button onclick="openAddModal()" 
                    class="w-full sm:w-auto lux-button px-4 py-2 rounded-lg hover:bg-amber-700 transition duration-200 flex items-center justify-center text-sm sm:text-base">
                <i class="fas fa-plus mr-2"></i>Add Event
            </button>
            
            <div class="flex items-center space-x-2 w-full sm:w-auto">
                <span class="text-sm text-gray-600 whitespace-nowrap">Show:</span>
                <select onchange="window.location.href = this.value" 
                        class="border border-gray-300 rounded px-3 py-1 text-sm w-full sm:w-auto">
                    <option value="<?php echo e(request()->fullUrlWithQuery(['per_page' => 10])); ?>" 
                            <?php echo e(request('per_page', 10) == 10 ? 'selected' : ''); ?>>10</option>
                    <option value="<?php echo e(request()->fullUrlWithQuery(['per_page' => 25])); ?>" 
                            <?php echo e(request('per_page', 10) == 25 ? 'selected' : ''); ?>>25</option>
                    <option value="<?php echo e(request()->fullUrlWithQuery(['per_page' => 50])); ?>" 
                            <?php echo e(request('per_page', 10) == 50 ? 'selected' : ''); ?>>50</option>
                </select>
            </div>
        </div>
    </div>
    
    <div class="overflow-x-auto px-4 sm:px-0">
        <?php if($events->count() > 0): ?>
            <table class="w-full min-w-full">
                <thead class="hidden sm:table-header-group">
                    <tr class="bg-gray-100/70 border-b border-gray-200">
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Poster</th>
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Event Details</th>
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">UKM</th>
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Date & Time</th>
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Location</th>
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Status</th>
                        <th class="p-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isPast = $event->event_date->isPast();
                        $isToday = $event->event_date->isToday();
                    ?>
                    <!-- Mobile View -->
                    <tr class="hover-row-table transition duration-150 block sm:table-row border-b sm:border-b-0">
                        <td class="block sm:hidden p-4 mx-2 sm:mx-0 my-2 sm:my-0 bg-white rounded-lg shadow-sm">
                            <div class="space-y-4">
                                <!-- Header with Poster -->
                                <div class="flex items-start space-x-3">
                                    <?php if($event->poster_image): ?>
                                        <img src="<?php echo e($event->poster_image); ?>" alt="<?php echo e($event->title); ?>" 
                                             class="w-16 h-16 rounded-lg object-cover shadow-sm border flex-shrink-0">
                                    <?php else: ?>
                                        <div class="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center border flex-shrink-0">
                                            <i class="fas fa-calendar-alt text-gray-400 text-xl"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div class="flex-1 min-w-0">
                                        <div class="font-semibold text-gray-900 text-lg"><?php echo e($event->title); ?></div>
                                        <div class="flex flex-wrap items-center gap-2 mt-2">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                                                <?php echo e($event->ukm->name); ?>

                                            </span>
                                            <?php if($isPast): ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                    <i class="fas fa-clock mr-1"></i> Past
                                                </span>
                                            <?php elseif($isToday): ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                    <i class="fas fa-star mr-1"></i> Today
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                    <i class="fas fa-calendar-check mr-1"></i> Upcoming
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Description -->
                                <?php if($event->description): ?>
                                <div class="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg border border-gray-100">
                                    <p class="line-clamp-2"><?php echo e($event->description); ?></p>
                                </div>
                                <?php endif; ?>

                                <!-- Date & Location -->
                                <div class="grid grid-cols-2 gap-3">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700">Date & Time</div>
                                        <div class="text-sm text-gray-900"><?php echo e($event->event_date->format('d M Y')); ?></div>
                                        <div class="text-xs text-gray-600"><?php echo e(date('H:i', strtotime($event->event_time))); ?></div>
                                    </div>
                                    <div>
                                        <div class="text-sm font-medium text-gray-700">Location</div>
                                        <div class="text-sm text-gray-900 truncate"><?php echo e($event->location); ?></div>
                                    </div>
                                </div>

                                <!-- Registration Link -->
                                <?php if($event->registration_link): ?>
                                <div class="text-xs">
                                    <a href="<?php echo e($event->registration_link); ?>" target="_blank" 
                                       class="text-amber-600 hover:text-amber-800 font-medium inline-flex items-center">
                                        <i class="fas fa-link mr-2"></i> Registration Link
                                    </a>
                                </div>
                                <?php endif; ?>

                                <!-- Actions -->
                                <div class="flex flex-col space-y-2 pt-4 border-t border-gray-200">
                                    <button onclick="editEvent(<?php echo e($event); ?>)" 
                                            class="w-full lux-button px-4 py-2.5 rounded-lg text-sm hover:bg-amber-700 transition duration-200 flex items-center justify-center gap-2 font-medium">
                                        <i class="fas fa-edit"></i> Edit Event
                                    </button>
                                    <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" 
                                          class="w-full" onsubmit="return confirmDeleteEvent('<?php echo e($event->title); ?>')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                                class="w-full bg-red-500 text-white px-4 py-2.5 rounded-lg text-sm hover:bg-red-600 transition duration-200 flex items-center justify-center gap-2 font-medium">
                                            <i class="fas fa-trash"></i> Delete Event
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </td>

                        <!-- Desktop View -->
                        <td class="hidden sm:table-cell p-4">
                            <?php if($event->poster_image): ?>
                                <img src="<?php echo e($event->poster_image); ?>" alt="<?php echo e($event->title); ?>" 
                                     class="w-16 h-16 rounded-lg object-cover shadow-sm border">
                            <?php else: ?>
                                <div class="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center border">
                                    <i class="fas fa-calendar-alt text-gray-400 text-xl"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="hidden sm:table-cell p-4">
                            <div class="font-semibold text-gray-900"><?php echo e($event->title); ?></div>
                            <div class="text-sm text-gray-600 mt-1"><?php echo e(Str::limit($event->description, 80)); ?></div>
                            <?php if($event->registration_link): ?>
                                <a href="<?php echo e($event->registration_link); ?>" target="_blank" 
                                   class="text-xs text-amber-600 hover:text-amber-800 mt-1 inline-block font-medium">
                                    <i class="fas fa-link mr-1"></i>Registration Link
                                </a>
                            <?php endif; ?>
                        </td>
                        <td class="hidden sm:table-cell p-4">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                                <?php echo e($event->ukm->name); ?>

                            </span>
                        </td>
                        <td class="hidden sm:table-cell p-4">
                            <div class="font-medium text-gray-900"><?php echo e($event->event_date->format('d M Y')); ?></div>
                            <div class="text-sm text-gray-600"><?php echo e(date('H:i', strtotime($event->event_time))); ?></div>
                            <div class="text-xs text-gray-400 mt-1">
                                <?php echo e($event->created_at->diffForHumans()); ?>

                            </div>
                        </td>
                        <td class="hidden sm:table-cell p-4 text-gray-700 max-w-xs">
                            <div class="text-sm"><?php echo e(Str::limit($event->location, 30)); ?></div>
                        </td>
                        <td class="hidden sm:table-cell p-4">
                            <?php if($isPast): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                    <i class="fas fa-clock mr-1"></i> Past
                                </span>
                            <?php elseif($isToday): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <i class="fas fa-star mr-1"></i> Today
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    <i class="fas fa-calendar-check mr-1"></i> Upcoming
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="hidden sm:table-cell p-4">
                            <div class="flex space-x-2">
                                <button onclick="editEvent(<?php echo e($event); ?>)" 
                                        class="lux-button px-3 py-1.5 rounded-lg text-sm hover:bg-amber-700 transition duration-200 flex items-center font-medium shadow-md shadow-amber-500/20">
                                    <i class="fas fa-edit mr-1"></i> Edit
                                </button>
                                <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" 
                                      class="inline" onsubmit="return confirmDeleteEvent('<?php echo e($event->title); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="bg-red-500 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-red-600 transition duration-200 flex items-center font-medium shadow-md shadow-red-500/20">
                                        <i class="fas fa-trash mr-1"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center py-12 px-4">
                <i class="fas fa-calendar-times text-4xl text-gray-300 mb-4"></i>
                <p class="text-gray-600 text-lg mb-2 font-semibold">No events match the criteria</p>
                <p class="text-gray-500 text-sm">
                    <?php if(request()->hasAny(['search', 'ukm_id', 'date_filter'])): ?>
                        Try adjusting your search or filters to see more results.
                    <?php else: ?>
                        No events have been created yet.
                    <?php endif; ?>
                </p>
                <button onclick="openAddModal()" 
                        class="mt-4 lux-button px-4 py-2 rounded-lg hover:bg-amber-700 transition duration-200 text-sm sm:text-base">
                    <i class="fas fa-plus mr-2"></i>Create First Event
                </button>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if($events->hasPages()): ?>
    <div class="px-4 sm:px-5 py-4 border-t border-gray-100 bg-gray-50/50">
        <div class="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
            <div class="text-sm text-gray-700 text-center sm:text-left font-medium">
                Showing **<?php echo e($events->firstItem()); ?>** to **<?php echo e($events->lastItem()); ?>** of **<?php echo e($events->total()); ?>** results
            </div>
            <div class="flex flex-wrap justify-center gap-2">
                <?php if($events->onFirstPage()): ?>
                    <span class="px-3 py-1 rounded-lg border border-gray-300 text-gray-400 cursor-not-allowed text-sm">
                        <i class="fas fa-angle-left"></i> Previous
                    </span>
                <?php else: ?>
                    <a href="<?php echo e($events->previousPageUrl()); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium">
                        <i class="fas fa-angle-left"></i> Previous
                    </a>
                <?php endif; ?>

                <?php
                    $currentPage = $events->currentPage();
                    $lastPage = $events->lastPage();
                    $start = max(1, $currentPage - 1);
                    $end = min($lastPage, $currentPage + 1);
                ?>

                <?php if($start > 1): ?>
                    <a href="<?php echo e($events->url(1)); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium">1</a>
                    <?php if($start > 2): ?>
                        <span class="px-3 py-1 text-gray-500">...</span>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page == $currentPage): ?>
                        <span class="px-3 py-1 rounded-lg border bg-amber-600 text-white text-sm font-medium"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($events->url($page)); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if($end < $lastPage): ?>
                    <?php if($end < $lastPage - 1): ?>
                        <span class="px-3 py-1 text-gray-500">...</span>
                    <?php endif; ?>
                    <a href="<?php echo e($events->url($lastPage)); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium"><?php echo e($lastPage); ?></a>
                <?php endif; ?>

                <?php if($events->hasMorePages()): ?>
                    <a href="<?php echo e($events->nextPageUrl()); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium">
                        Next <i class="fas fa-angle-right"></i>
                    </a>
                <?php else: ?>
                    <span class="px-3 py-1 rounded-lg border border-gray-300 text-gray-400 cursor-not-allowed text-sm">
                        Next <i class="fas fa-angle-right"></i>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Add Event Modal -->
<dialog id="addEventModal" class="modal-lux bg-white">
    <div class="flex justify-between items-center p-4 sm:p-6 border-b border-gray-200 bg-gray-50 rounded-t-xl">
        <h3 class="text-lg sm:text-xl font-bold text-gray-800 flex items-center">
            <i class="fas fa-plus-circle mr-2 lux-gold-text"></i> Create New Event
        </h3>
        <button onclick="closeAddModal()" class="text-gray-400 hover:text-gray-700 transition duration-200">
            <i class="fas fa-times text-lg"></i>
        </button>
    </div>
    
    <form id="addEventForm" action="<?php echo e(route('admin.events.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="p-4 sm:p-6 space-y-5 max-h-[70vh] overflow-y-auto">
            <?php if($errors->any() && !session('edit_errors')): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                    <strong class="font-medium">Please fix the following errors:</strong>
                    <ul class="list-disc list-inside text-sm mt-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">UKM *</label>
                    <select name="ukm_id" required 
                            class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                   <?php echo e($errors->has('ukm_id') && !session('edit_errors') ? 'border-red-500' : ''); ?>">
                        <option value="">Select UKM</option>
                        <?php $__currentLoopData = $ukms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ukm->id); ?>" <?php echo e(old('ukm_id') == $ukm->id ? 'selected' : ''); ?>>
                                <?php echo e($ukm->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('ukm_id') && !session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('ukm_id')); ?></p>
                    <?php endif; ?>
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Event Title *</label>
                    <input type="text" name="title" required 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('title') && !session('edit_errors') ? 'border-red-500' : ''); ?>"
                           value="<?php echo e(old('title')); ?>"
                           placeholder="Enter event title">
                    <?php if($errors->has('title') && !session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('title')); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Description *</label>
                <textarea name="description" required 
                          class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                 <?php echo e($errors->has('description') && !session('edit_errors') ? 'border-red-500' : ''); ?>"
                          rows="4" 
                          placeholder="Describe your event..."><?php echo e(old('description')); ?></textarea>
                <?php if($errors->has('description') && !session('edit_errors')): ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('description')); ?></p>
                <?php endif; ?>
                <p class="text-gray-500 text-xs mt-2">Minimal 10 karakter, maksimal 2000 karakter</p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Event Date *</label>
                    <input type="date" name="event_date" required 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('event_date') && !session('edit_errors') ? 'border-red-500' : ''); ?>"
                           value="<?php echo e(old('event_date')); ?>"
                           min="<?php echo e(date('Y-m-d')); ?>">
                    <?php if($errors->has('event_date') && !session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('event_date')); ?></p>
                    <?php endif; ?>
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Event Time *</label>
                    <input type="time" name="event_time" required 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('event_time') && !session('edit_errors') ? 'border-red-500' : ''); ?>"
                           value="<?php echo e(old('event_time')); ?>">
                    <?php if($errors->has('event_time') && !session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('event_time')); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Location *</label>
                <input type="text" name="location" required 
                       class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                              <?php echo e($errors->has('location') && !session('edit_errors') ? 'border-red-500' : ''); ?>"
                       value="<?php echo e(old('location')); ?>"
                       placeholder="Enter event location">
                <?php if($errors->has('location') && !session('edit_errors')): ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('location')); ?></p>
                <?php endif; ?>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Poster Image</label>
                    <input type="file" name="poster_image" accept="image/*"
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0
                                  file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700
                                  hover:file:bg-amber-100
                                  <?php echo e($errors->has('poster_image') && !session('edit_errors') ? 'border-red-500' : ''); ?>">
                    <?php if($errors->has('poster_image') && !session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('poster_image')); ?></p>
                    <?php endif; ?>
                    <p class="text-gray-500 text-xs mt-2">Format: JPEG, PNG, JPG, GIF, WebP | Maksimal 5MB</p>
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Registration Link</label>
                    <input type="url" name="registration_link" 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('registration_link') && !session('edit_errors') ? 'border-red-500' : ''); ?>"
                           value="<?php echo e(old('registration_link')); ?>"
                           placeholder="https://example.com/register">
                    <?php if($errors->has('registration_link') && !session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('registration_link')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 p-4 sm:p-6 border-t border-gray-100 bg-gray-50 rounded-b-xl">
            <button type="button" onclick="closeAddModal()" 
                    class="px-4 py-2.5 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition duration-200 font-medium text-sm sm:text-base">
                Cancel
            </button>
            <button type="submit" 
                    class="lux-button px-4 py-2.5 rounded-lg hover:bg-amber-700 transition duration-200 font-medium flex items-center justify-center text-sm sm:text-base">
                <i class="fas fa-save mr-2"></i> Save Event
            </button>
        </div>
    </form>
</dialog>

<!-- Edit Event Modal -->
<dialog id="editEventModal" class="modal-lux bg-white">
    <div class="flex justify-between items-center p-4 sm:p-6 border-b border-gray-200 bg-gray-50 rounded-t-xl">
        <h3 class="text-lg sm:text-xl font-bold text-gray-800 flex items-center">
            <i class="fas fa-edit mr-2 lux-gold-text"></i> Edit Event
        </h3>
        <button onclick="closeEditModal()" class="text-gray-400 hover:text-gray-700 transition duration-200">
            <i class="fas fa-times text-lg"></i>
        </button>
    </div>
    
    <form id="editEventForm" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="p-4 sm:p-6 space-y-5 max-h-[70vh] overflow-y-auto">
            <?php if($errors->any() && session('edit_errors')): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                    <strong class="font-medium">Please fix the following errors:</strong>
                    <ul class="list-disc list-inside text-sm mt-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">UKM *</label>
                    <select name="ukm_id" required 
                            class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                   <?php echo e($errors->has('ukm_id') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                            id="editUkmId">
                        <?php $__currentLoopData = $ukms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ukm->id); ?>"><?php echo e($ukm->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('ukm_id') && session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('ukm_id')); ?></p>
                    <?php endif; ?>
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Event Title *</label>
                    <input type="text" name="title" required 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('title') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                           id="editTitle">
                    <?php if($errors->has('title') && session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('title')); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Description *</label>
                <textarea name="description" required 
                          class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                 <?php echo e($errors->has('description') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                          rows="4" 
                          id="editDescription"></textarea>
                <?php if($errors->has('description') && session('edit_errors')): ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('description')); ?></p>
                <?php endif; ?>
                <p class="text-gray-500 text-xs mt-2">Minimal 10 karakter, maksimal 2000 karakter</p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Event Date *</label>
                    <input type="date" name="event_date" required 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('event_date') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                           id="editEventDate">
                    <?php if($errors->has('event_date') && session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('event_date')); ?></p>
                    <?php endif; ?>
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Event Time *</label>
                    <input type="time" name="event_time" required 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('event_time') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                           id="editEventTime">
                    <?php if($errors->has('event_time') && session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('event_time')); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Location *</label>
                <input type="text" name="location" required 
                       class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                              <?php echo e($errors->has('location') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                       id="editLocation">
                <?php if($errors->has('location') && session('edit_errors')): ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('location')); ?></p>
                <?php endif; ?>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Poster Image</label>
                    <input type="file" name="poster_image" accept="image/*"
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0
                                  file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700
                                  hover:file:bg-amber-100
                                  <?php echo e($errors->has('poster_image') && session('edit_errors') ? 'border-red-500' : ''); ?>">
                    <?php if($errors->has('poster_image') && session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('poster_image')); ?></p>
                    <?php endif; ?>
                    <div class="mt-3" id="currentPoster">
                        <p class="text-sm font-medium text-gray-600 mb-2">Current Poster:</p>
                        <img id="currentPosterImage" src="" class="w-32 h-32 rounded-lg border object-cover shadow-sm">
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Registration Link</label>
                    <input type="url" name="registration_link" 
                           class="w-full border border-gray-300 rounded-lg px-4 py-2.5 input-lux:focus transition duration-200 text-sm sm:text-base
                                  <?php echo e($errors->has('registration_link') && session('edit_errors') ? 'border-red-500' : ''); ?>"
                           id="editRegistrationLink">
                    <?php if($errors->has('registration_link') && session('edit_errors')): ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($errors->first('registration_link')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 p-4 sm:p-6 border-t border-gray-100 bg-gray-50 rounded-b-xl">
            <button type="button" onclick="closeEditModal()" 
                    class="px-4 py-2.5 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition duration-200 font-medium text-sm sm:text-base">
                Cancel
            </button>
            <button type="submit" 
                    class="lux-button px-4 py-2.5 rounded-lg hover:bg-amber-700 transition duration-200 font-medium flex items-center justify-center text-sm sm:text-base">
                <i class="fas fa-save mr-2"></i> Update Event
            </button>
        </div>
    </form>
</dialog>

<script>
function confirmDeleteEvent(title) {
    return confirm(`Are you sure you want to delete event "${title}"? This action cannot be undone.`);
}

// Modal Functions
function openAddModal() {
    const modal = document.getElementById('addEventModal');
    modal.showModal();
    document.getElementById('addEventForm').reset();
    
    const errorInputs = document.querySelectorAll('#addEventForm .border-red-500');
    errorInputs.forEach(input => input.classList.remove('border-red-500'));
    
    const errorMessages = document.querySelectorAll('#addEventForm .text-red-500');
    errorMessages.forEach(msg => msg.remove());
    
    // Mobile positioning
    if (window.innerWidth < 640) {
        modal.style.margin = '1rem auto';
        modal.style.maxHeight = '90vh';
        modal.style.overflowY = 'auto';
    }
}

function closeAddModal() {
    document.getElementById('addEventModal').close();
}

function closeEditModal() {
    document.getElementById('editEventModal').close();
}

function editEvent(event) {
    const form = document.getElementById('editEventForm');
    form.action = `/admin/events/${event.id}`;
    
    document.getElementById('editUkmId').value = event.ukm_id;
    document.getElementById('editTitle').value = event.title;
    document.getElementById('editDescription').value = event.description;
    document.getElementById('editEventDate').value = event.event_date;
    document.getElementById('editEventTime').value = event.event_time;
    document.getElementById('editLocation').value = event.location;
    document.getElementById('editRegistrationLink').value = event.registration_link || '';
    
    const currentPoster = document.getElementById('currentPoster');
    const currentPosterImage = document.getElementById('currentPosterImage');
    if (event.poster_image) {
        currentPosterImage.src = event.poster_image;
        currentPoster.style.display = 'block';
    } else {
        currentPoster.style.display = 'none';
    }
    
    const modal = document.getElementById('editEventModal');
    modal.showModal();
    
    // Mobile positioning
    if (window.innerWidth < 640) {
        modal.style.margin = '1rem auto';
        modal.style.maxHeight = '90vh';
        modal.style.overflowY = 'auto';
    }
}

// Real-time validation
document.addEventListener('DOMContentLoaded', function() {
    const hasAddErrors = <?php echo e($errors->any() && !session('edit_errors') ? 'true' : 'false'); ?>;
    if (hasAddErrors) {
        setTimeout(() => openAddModal(), 300);
    }

    const hasEditErrors = <?php echo e($errors->any() && session('edit_errors') ? 'true' : 'false'); ?>;
    if (hasEditErrors) {
        setTimeout(() => {
            const modal = document.getElementById('editEventModal');
            modal.showModal();
            if (window.innerWidth < 640) {
                modal.style.margin = '1rem auto';
                modal.style.maxHeight = '90vh';
                modal.style.overflowY = 'auto';
            }
        }, 300);
    }

    // Close modals on backdrop click
    document.getElementById('addEventModal').addEventListener('click', function(e) {
        if (e.target === this) closeAddModal();
    });
    
    document.getElementById('editEventModal').addEventListener('click', function(e) {
        if (e.target === this) closeEditModal();
    });

    // Image validation
    const imageInputs = document.querySelectorAll('input[type="file"]');
    imageInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Validate file size (5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('File size must be less than 5MB');
                    this.value = '';
                    return;
                }
            }
        });
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/admin/events/index.blade.php ENDPATH**/ ?>