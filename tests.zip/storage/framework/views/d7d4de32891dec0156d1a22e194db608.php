<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI-UKM - <?php echo $__env->yieldContent('title'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-blue-600 text-white shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <a href="<?php echo e(route('home')); ?>" class="text-xl font-bold">SI-UKM</a>
                
                <div class="flex items-center space-x-4">
                    <?php if(auth()->guard()->check()): ?>
                        <span>Halo, <?php echo e(auth()->user()->name); ?></span>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded">
                                <i class="fas fa-sign-out-alt mr-1"></i>Logout
                            </button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="bg-green-500 hover:bg-green-600 px-3 py-1 rounded">
                            <i class="fas fa-sign-in-alt mr-1"></i>Login
                        </a>
                        <a href="<?php echo e(route('register')); ?>" class="bg-purple-500 hover:bg-purple-600 px-3 py-1 rounded">
                            <i class="fas fa-user-plus mr-1"></i>Register
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Flash Messages -->
    <?php if(session('success')): ?>
        <div class="fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded shadow-lg">
            <i class="fas fa-check-circle mr-2"></i><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="fixed top-20 right-4 bg-red-500 text-white px-6 py-3 rounded shadow-lg">
            <i class="fas fa-exclamation-circle mr-2"></i><?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/layouts/app.blade.php ENDPATH**/ ?>