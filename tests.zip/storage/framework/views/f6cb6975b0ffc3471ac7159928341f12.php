

<?php $__env->startSection('content'); ?>


<section class="md:ml-[-30px] md:mr-[-30px] py-10 md:py-16 px-4 md:px-0 flex flex-col md:flex-row justify-between items-center bg-white shadow-md">
    <div class="max-w-7xl mx-auto w-full flex flex-col md:flex-row justify-between items-center md:px-24 lg:px-24">
        <div class="w-full md:w-2/3 mb-8 md:mb-0 text-center md:text-left">
            <h1 class="text-3xl sm:text-4xl md:text-4xl lg:text-4xl font-bold leading-tight text-gray-900 px-4">
                Temukan 
                <span class="text-orange-600">Tempatmu</span>, 
                <span class="text-orange-600">Wujudkan</span> 
                <br class="hidden sm:inline">
                <span class="text-orange-600">Potensimu</span>, 
                Raih Mimpimu!
            </h1>
        </div>
        <div class="w-full md:w-2/3 text-center md:text-left max-w-md px-4">
            <p class="text-base text-gray-600 mb-6 mx-auto md:ml-auto"> 
                Bergabunglah dengan UKM untuk mengasah minat, bakat, 
                dan kepemimpinanmu. Kampus bukan hanya soal kuliah. 
                Tapi juga tentang bertumbuh, bersosial, dan berkarya!
            </p>
            
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('user.ukm.list')); ?>" class="inline-block px-12 py-2 bg-gray-800 text-white font-semibold rounded-full hover:bg-gray-700 transition duration-300">
                    Disini!
                </a>
            <?php else: ?>
                <button onclick="showLoginModal()" class="inline-block px-10 py-3 bg-gray-800 text-white font-semibold rounded-full hover:bg-gray-700 transition duration-300">
                    Gabung Sekarang!
                </button>
            <?php endif; ?>
        </div>
    </div>
</section>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-24 py-10">


    
    <section class="mb-12">
        <div class="flex justify-between items-center mb-6 px-4 sm:px-0">
            <h2 class="text-2xl sm:text-3xl font-bold">Trending Event</h2>
      </div>

        <div class="relative">
            <div class="overflow-hidden">
                
                
                <div class="flex space-x-4 md:space-x-8 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory" id="events-slider">
                    <?php $__currentLoopData = $trendingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="flex-shrink-0 w-[calc(50%-8px)] sm:w-[calc(50%-16px)] lg:w-[calc(50%-16px)] snap-start">
                            <?php if(auth()->guard()->check()): ?>
                                
<div class="flex border rounded-lg shadow-lg overflow-hidden bg-white hover:shadow-xl transition-all duration-300 cursor-pointer event-card h-40 sm:h-80 lg:h-96"
    data-event-title="<?php echo e($event->title); ?>"
    data-event-description="<?php echo e($event->description); ?>"
    data-event-date="<?php echo e($event->event_date); ?>"
    data-event-time="<?php echo e($event->event_time); ?>"
    data-event-location="<?php echo e($event->location); ?>"
    data-event-poster="<?php echo e($event->poster_image ?? ''); ?>"
    data-event-ukm="<?php echo e($event->ukm->name); ?>">
                            <?php else: ?>
                                <div class="flex border rounded-lg shadow-lg overflow-hidden bg-white hover:shadow-xl transition-all duration-300 cursor-pointer event-card-guest h-40 sm:h-80 lg:h-96"
                                    onclick="showLoginModal()">
                            <?php endif; ?>
                                
                                    
                                    <div class="w-2/4 sm:w-2/4 bg-gray-100 relative flex justify-center items-center">
                                        <?php if($event->poster_image): ?>
                                            <img src="<?php echo e($event->poster_image); ?>" alt="<?php echo e($event->title); ?>" class="w-full h-full object-cover">
                                        <?php else: ?>
                                            <div class="w-full h-full bg-gradient-to-br from-orange-100 to-orange-200 flex items-center justify-center">
                                                <i class="fas fa-calendar-alt text-gray-400 text-2xl sm:text-3xl"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    
                                    <div class="w-2/4 sm:w-2/4 p-3 sm:p-6 space-y-1 sm:space-y-2 flex flex-col justify-between">
                                        <div>
                                            
                                            <h3 class="text-sm sm:text-lg font-semibold line-clamp-2 leading-tight"><?php echo e($event->title); ?></h3>
                                            <p class="text-xs text-gray-500 mt-1 hidden sm:block"><i class="far fa-calendar-alt mr-1"></i> <?php echo e($event->event_date->format('d M Y')); ?> • <?php echo e($event->event_time); ?></p>
                                        </div>
                                        
                                        
                                        <p class="text-sm text-gray-600 line-clamp-3 sm:line-clamp-none"><?php echo e(Str::limit($event->description, 290)); ?></p>
                                        
                                        <div class="mt-auto pt-1">
                                                                     <div class="flex items-center text-gray-600/90 text-[10px] sm:text-xs">
                                        <i class="fab fa-instagram mr-1 sm:mr-1 text-[15px]"></i>
                                       <p class="text-xs text-gray-600 font-medium"><?php echo e($event->ukm->instagram); ?></p>
                                    </div>
                                            
                                            <div class="flex justify-between items-end mt-1">
                                                <span class="text-xs text-gray-400 hidden sm:block"><?php echo e($event->created_at->diffForHumans()); ?></span>
    
                                            </div>
                                        </div>
                                    </div>
                                <?php if(auth()->guard()->check()): ?>
                                    </div>
                                <?php else: ?>
                                    </div>
                                <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
            <div class="flex justify-center mt-6 space-x-2">
                <?php $__currentLoopData = $trendingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-2 h-2 rounded-full bg-gray-300 transition-colors duration-300 cursor-pointer carousel-dot <?php echo e($key === 0 ? 'active !bg-gray-600' : ''); ?>"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    

<section class="mb-12">
    
        <div class="lg:mx-[-125px] mx-[-15px] bg-white pt-10 pb-16 shadow-inner md:shadow-none">
            
            
            <div class="px-4 sm:px-6 lg:px-24">
                <div class="flex justify-center items-center mb-10">
                    <h2 class="text-2xl sm:text-3xl font-bold">Feed</h2>
                </div>
            </div>
        
        
        <div class="lg:mx-[125px]  grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 px-4 sm:px-0">
            <?php $__currentLoopData = $trendingFeeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(auth()->guard()->check()): ?>
                <div class="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-all duration-300 cursor-pointer feed-card"
                    data-feed-id="<?php echo e($feed->id); ?>"
                    data-feed-title="<?php echo e($feed->title); ?>"
                    data-feed-content="<?php echo e($feed->content); ?>"
                    data-feed-image="<?php echo e($feed->image ?? ''); ?>"
                    data-feed-ukm="<?php echo e($feed->ukm->name); ?>"
                    data-feed-created="<?php echo e($feed->created_at->format('d M Y, H:i')); ?>"
                    data-feed-views="1.2k">
            <?php else: ?>
                <div class="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-all duration-300 cursor-pointer feed-card-guest"
                    onclick="showLoginModal()">
            <?php endif; ?>

                    <div class="w-full h-40 sm:h-40 lg:h-[220px] bg-gray-200 flex justify-center items-center text-gray-500 rounded-t-lg overflow-hidden">
                        <?php if($feed->image): ?>
                            <img src="<?php echo e($feed->image); ?>" alt="<?php echo e($feed->title); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <div class="w-full h-full bg-gray-200 flex justify-center items-center">
                                <span class="text-4xl text-gray-400">×</span>
                                <span class="text-4xl text-gray-400">×</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="p-3"> 
                        
                        <h3 class="text-sm sm:text-base font-semibold mb-1 line-clamp-1">
                            <?php echo e($feed->title); ?>

                        </h3>
                        
                        
                        <p class="text-xs sm:text-sm text-gray-600 line-clamp-2">
                            <?php echo e(Str::limit($feed->content, 65)); ?>

                        </p>
                        <span class="text-xs text-gray-400 block mt-2"><?php echo e($feed->ukm->name); ?></span>
                    </div>
                    
                <?php if(auth()->guard()->check()): ?>
                    </div>
                <?php else: ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($trendingFeeds->count() == 0): ?>
        <div class="px-4 sm:px-0">
            <div class="text-center py-12 border rounded-lg mt-6 bg-gray-50 col-span-2 lg:col-span-4">
                <div class="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-10 h-10 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-12 5h8a2 2 0 002-2V7a2 2 0 00-2-2H8a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                </div>
                <p class="text-gray-600 text-lg">Belum ada feed terbaru yang diposting.</p>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('user.feeds.index')); ?>" class="text-orange-600 hover:text-orange-700 font-medium mt-2 inline-block">
                        Jelajahi Feed Lainnya →
                    </a>
                <?php else: ?>
                    <button onclick="showLoginModal()" class="text-orange-600 hover:text-orange-700 font-medium mt-2">
                        Jelajahi Feed Lainnya →
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>


    
    <section class="mb-12">
        <div class="flex justify-center items-center mb-10">
            <h2 class="text-2xl sm:text-3xl font-bold">UKM Populer</h2>
        </div>

        
        <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            <?php $__currentLoopData = $ukms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('user.ukm.detail', $ukm->id)); ?>" class="ukm-card block bg-white rounded-xl shadow-lg overflow-hidden transform hover:shadow-2xl hover:scale-[1.02] transition duration-300">
            <?php else: ?>
                <div onclick="showLoginModal()" class="ukm-card bg-white rounded-xl shadow-lg overflow-hidden transform hover:shadow-2xl hover:scale-[1.02] transition duration-300 cursor-pointer">
            <?php endif; ?>
                
                    <div class="h-28 sm:h-32 lg:h-36 relative bg-gray-100 flex items-center justify-center">
                        
                        <?php if($ukm->logo): ?>
                            <img src="<?php echo e($ukm->logo); ?>" alt="Cover <?php echo e($ukm->name); ?>" class="w-full h-full object-cover brightness-75 blur-sm opacity-80">
                        <?php else: ?>
                            <div class="w-full h-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
                                <i class="fas fa-camera text-3xl sm:text-4xl text-gray-500"></i>
                            </div>
                        <?php endif; ?>

                        
                        <div class="absolute top-2 right-2 z-10 ukm-badge transition duration-300">
                            <span class="px-2 py-1 bg-orange-600/90 text-white text-xs font-semibold rounded-full shadow-md">
                                <?php echo e($ukm->category->name ?? 'Umum'); ?>

                            </span>
                        </div>

                        
                        
                        <div class="absolute top-full left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 border-3 sm:border-4 border-white rounded-full overflow-hidden bg-white shadow-xl z-20 ukm-logo-container transition-all duration-300">
                            <?php if($ukm->logo): ?>
                                <img src="<?php echo e($ukm->logo); ?>" alt="Logo <?php echo e($ukm->name); ?>" class="w-full h-full object-cover p-1">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center bg-gray-200">
                                    <i class="fas fa-users text-lg sm:text-xl text-gray-500"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

<div class="pt-10 sm:pt-14 lg:pt-16 pb-4 sm:pb-6 px-3 sm:px-4 text-center">
    <h3 class="text-base sm:text-lg font-bold text-gray-800 mb-1 line-clamp-1"><?php echo e($ukm->name); ?></h3>
    
    
    <p class="text-xs sm:text-sm text-gray-500 mb-2 sm:mb-4 line-clamp-2 sm:line-clamp-3">
        <?php echo e(Str::limit($ukm->description, 100)); ?>

    </p>
    
    <div class="flex flex-col items-center justify-center space-y-1 text-sm text-gray-500 mb-3 sm:mb-4 border-t pt-2 sm:pt-3 mt-2 sm:mt-3">
        <?php if($ukm->instagram): ?>
            <div class="flex items-center text-gray-600/90 text-[10px] sm:text-xs">
                <i class="fab fa-instagram mr-1 sm:mr-1 text-[15px]"></i>
                <span><?php echo e($ukm->instagram); ?></span>
            </div>
        <?php endif; ?>
        
    </div>
</div>

            <?php if(auth()->guard()->check()): ?>
                </a>
            <?php else: ?>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

            <?php if($ukms->count() == 0): ?>
            <div class="col-span-2 lg:col-span-3 text-center py-12 border rounded-lg bg-gray-50">
                <div class="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-users text-gray-500 text-2xl"></i>
                </div>
                <p class="text-gray-600 text-lg">Belum ada UKM terdaftar.</p>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('user.ukm.list')); ?>" class="text-orange-600 hover:text-orange-700 font-medium mt-2 inline-block">
                        Jelajahi UKM Lainnya →
                    </a>
                <?php else: ?>
                    <button onclick="showLoginModal()" class="text-orange-600 hover:text-orange-700 font-medium mt-2">
                        Jelajahi UKM Lainnya →
                    </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>
    </section> 
</div>


    

   
    <?php echo $__env->make('layouts.partials.modals-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<style>
    .carousel-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #d1d5db;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .carousel-dot.active {
        background-color: #3b82f6;
    }

    .scrollbar-hide::-webkit-scrollbar {
        display: none;
    }
    
    .scrollbar-hide {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <?php echo $__env->make('layouts.partials.scripts-modal-universal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 1. Inisialisasi modal
            if (window.ModalFunctions) {
                ModalFunctions.initAllModals();
                ModalFunctions.bindEventCardsToModal();
                ModalFunctions.bindFeedCardsToModal();
            }

            // 2. Handle guest clicks
            document.querySelectorAll('.event-card-guest, .feed-card-guest, .ukm-card[onclick]').forEach(card => {
                card.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (typeof window.showLoginModal === 'function') {
                        window.showLoginModal();
                    }
                });
            });

            // 3. Carousel functionality (khusus dashboard)
            const slider = document.getElementById('events-slider');
            const dots = document.querySelectorAll('.carousel-dot');
            
            if (slider && dots.length > 0) {
                const scrollAmount = 536; 
                let currentSlide = 0;
                
                function updateDots() {
                    dots.forEach((dot, index) => {
                        dot.classList.toggle('active', index === currentSlide);
                    });
                }
                
                dots.forEach((dot, index) => {
                    dot.addEventListener('click', () => {
                        currentSlide = index;
                        slider.scrollTo({ left: index * scrollAmount, behavior: 'smooth' });
                        updateDots();
                    });
                });
                
                // Auto slide
                const slideInterval = setInterval(() => {
                    currentSlide = (currentSlide + 1) % dots.length;
                    slider.scrollTo({ left: currentSlide * scrollAmount, behavior: 'smooth' });
                    updateDots();
                }, 5000);

                slider.addEventListener('scroll', () => {
                    clearInterval(slideInterval);
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/user/dashboard.blade.php ENDPATH**/ ?>