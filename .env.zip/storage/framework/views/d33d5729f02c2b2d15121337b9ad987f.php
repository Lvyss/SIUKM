

<?php $__env->startSection('content'); ?>
<style>
    /* CUSTOM STYLES LUXURY SAMA KAYA YANG LAIN */
    .lux-bg { background-color: #f3f4f6; }
    .lux-gold-text { color: #b45309; } 

    .floating-card {
        background-color: white;
        border-radius: 12px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        border: 1px solid #e5e7eb;
    }
    .floating-card:hover {
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        transform: translateY(-2px);
    }
    
    .lux-button {
        background-color: #b45309;
        color: white;
        transition: background-color 0.2s;
    }
    .lux-button:hover {
        background-color: #92400e;
    }
    
    .input-lux:focus {
        border-color: #b45309;
        box-shadow: 0 0 0 2px rgba(180, 83, 9, 0.4);
    }

    dialog.modal-lux::backdrop {
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(2px);
    }
    dialog.modal-lux {
        animation: fadeIn 0.3s ease-out;
        border: none;
        padding: 0;
        border-radius: 12px;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
    }
    
    .hover-row-table:hover {
        background-color: #fffaf0;
    }
</style>

<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight">Registrations Matrix & Management</h1>
    <div class="text-sm font-semibold lux-gold-text px-3 py-1 rounded-full border border-gray-300 bg-amber-50">
        <i class="fas fa-clipboard-check mr-1 lux-gold-text"></i> Total: **<?php echo e($registrations->total()); ?> registrations**
    </div>
</div>

<!-- Statistics Cards -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="floating-card p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-blue-100">
                <i class="fas fa-list text-blue-600 text-sm"></i>
            </div>
            <div class="ml-3">
                <p class="text-sm font-medium text-gray-600">Total</p>
                <p class="text-xl font-bold text-gray-900"><?php echo e($totalCount); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-yellow-100">
                <i class="fas fa-clock text-yellow-600 text-sm"></i>
            </div>
            <div class="ml-3">
                <p class="text-sm font-medium text-gray-600">Pending</p>
                <p class="text-xl font-bold text-gray-900"><?php echo e($pendingCount); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-green-100">
                <i class="fas fa-check text-green-600 text-sm"></i>
            </div>
            <div class="ml-3">
                <p class="text-sm font-medium text-gray-600">Approved</p>
                <p class="text-xl font-bold text-gray-900"><?php echo e($approvedCount); ?></p>
            </div>
        </div>
    </div>
    
    <div class="floating-card p-4">
        <div class="flex items-center">
            <div class="p-2 rounded-full bg-red-100">
                <i class="fas fa-times text-red-600 text-sm"></i>
            </div>
            <div class="ml-3">
                <p class="text-sm font-medium text-gray-600">Rejected</p>
                <p class="text-xl font-bold text-gray-900"><?php echo e($rejectedCount); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="floating-card mb-6">
    <div class="p-5 border-b border-gray-100">
        <h2 class="text-lg font-bold text-gray-800 flex items-center">
            <i class="fas fa-filter mr-2 lux-gold-text"></i> Search & Filters
        </h2>
    </div>
    <div class="p-5">
        <div class="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            <!-- Status Filter -->
            <div class="flex flex-wrap gap-2">
                <button onclick="filterRegistrations('all')" 
                        class="px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 
                               <?php echo e(request('status') == 'all' || !request('status') ? 'bg-amber-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    All (<?php echo e($totalCount); ?>)
                </button>
                <button onclick="filterRegistrations('pending')" 
                        class="px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 
                               <?php echo e(request('status') == 'pending' ? 'bg-yellow-600 text-white' : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'); ?>">
                    Pending (<?php echo e($pendingCount); ?>)
                </button>
                <button onclick="filterRegistrations('approved')" 
                        class="px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 
                               <?php echo e(request('status') == 'approved' ? 'bg-green-600 text-white' : 'bg-green-100 text-green-800 hover:bg-green-200'); ?>">
                    Approved (<?php echo e($approvedCount); ?>)
                </button>
                <button onclick="filterRegistrations('rejected')" 
                        class="px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 
                               <?php echo e(request('status') == 'rejected' ? 'bg-red-600 text-white' : 'bg-red-100 text-red-800 hover:bg-red-200'); ?>">
                    Rejected (<?php echo e($rejectedCount); ?>)
                </button>
            </div>

            <!-- Search -->
            <div class="relative w-full lg:w-64">
                <input type="text" id="searchInput" placeholder="Search by user or UKM..." 
                       class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg input-lux:focus transition duration-200">
                <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
        </div>
    </div>
</div>

<!-- Registrations Table -->
<div class="floating-card overflow-hidden">
    <div class="flex justify-between items-center p-5 border-b bg-gray-50/50">
        <h2 class="text-lg font-bold text-gray-800 flex items-center">
            <i class="fas fa-database mr-2 lux-gold-text"></i>
            <?php if(request('status') && request('status') != 'all'): ?>
                <?php echo e(ucfirst(request('status'))); ?> Registration Requests
            <?php else: ?>
                All Registration Requests
            <?php endif; ?>
        </h2>
        
        <div class="flex items-center space-x-2">
            <span class="text-xs font-medium text-gray-600 uppercase">Show:</span>
            <select onchange="window.location.href = this.value" 
                    class="border border-gray-300 rounded-lg px-3 py-1 text-sm input-lux:focus">
                <option value="<?php echo e(request()->fullUrlWithQuery(['per_page' => 10])); ?>" 
                        <?php echo e(request('per_page', 10) == 10 ? 'selected' : ''); ?>>10</option>
                <option value="<?php echo e(request()->fullUrlWithQuery(['per_page' => 25])); ?>" 
                        <?php echo e(request('per_page', 10) == 25 ? 'selected' : ''); ?>>25</option>
                <option value="<?php echo e(request()->fullUrlWithQuery(['per_page' => 50])); ?>" 
                        <?php echo e(request('per_page', 10) == 50 ? 'selected' : ''); ?>>50</option>
            </select>
        </div>
    </div>
    
    <div class="overflow-x-auto">
        <?php if($registrations->count() > 0): ?>
            <table class="w-full min-w-full">
                <thead>
                    <tr class="bg-gray-100/70 border-b border-gray-200">
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                            Applicant & UKM
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                            Details
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                            Status
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                            Date
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover-row-table transition duration-150 registration-row" 
                        data-user="<?php echo e(strtolower($registration->user->name)); ?>"
                        data-ukm="<?php echo e(strtolower($registration->ukm->name)); ?>"
                        data-status="<?php echo e($registration->status); ?>">
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 bg-gradient-to-r from-amber-500 to-yellow-600 rounded-full flex items-center justify-center">
                                    <span class="text-white font-semibold text-sm">
                                        <?php echo e(substr($registration->user->name, 0, 1)); ?>

                                    </span>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900"><?php echo e($registration->user->name); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($registration->user->email); ?></div>
                                    <div class="mt-1">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">
                                            <i class="fas fa-users mr-1 text-xs"></i>
                                            <?php echo e($registration->ukm->name); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="max-w-xs">
                                <div class="text-sm text-gray-900 mb-2">
                                    <strong class="text-gray-700">Motivation:</strong> 
                                    <span class="text-gray-600"><?php echo e(Str::limit($registration->motivation, 80)); ?></span>
                                </div>
                                
                                <?php if($registration->experience): ?>
                                <div class="text-sm text-gray-600 mb-1">
                                    <strong class="text-gray-700">Experience:</strong> 
                                    <span><?php echo e(Str::limit($registration->experience, 50)); ?></span>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($registration->skills): ?>
                                <div class="text-sm text-gray-600">
                                    <strong class="text-gray-700">Skills:</strong> 
                                    <span><?php echo e(Str::limit($registration->skills, 50)); ?></span>
                                </div>
                                <?php endif; ?>
                                
                                <button onclick="showDetails(<?php echo e($registration->id); ?>)" 
                                        class="mt-2 text-amber-600 hover:text-amber-800 text-xs font-medium transition duration-200 flex items-center">
                                    <i class="fas fa-eye mr-1"></i>View Details
                                </button>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex flex-col space-y-2">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    <?php echo e($registration->status == 'pending' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' : ''); ?>

                                    <?php echo e($registration->status == 'approved' ? 'bg-green-100 text-green-800 border border-green-200' : ''); ?>

                                    <?php echo e($registration->status == 'rejected' ? 'bg-red-100 text-red-800 border border-red-200' : ''); ?>">
                                    <i class="fas 
                                        <?php echo e($registration->status == 'pending' ? 'fa-clock' : ''); ?>

                                        <?php echo e($registration->status == 'approved' ? 'fa-check' : ''); ?>

                                        <?php echo e($registration->status == 'rejected' ? 'fa-times' : ''); ?> 
                                        mr-1 text-xs"></i>
                                    <?php echo e(ucfirst($registration->status)); ?>

                                </span>
                                
                                <?php if($registration->status != 'pending'): ?>
                                    <div class="text-xs text-gray-500">
                                        <div>By: <?php echo e($registration->approver->name ?? 'System'); ?></div>
                                        <div><?php echo e($registration->approved_at?->format('M d, Y H:i')); ?></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <div class="flex flex-col">
                                <span class="font-medium text-gray-900"><?php echo e($registration->created_at->format('M d, Y')); ?></span>
                                <span class="text-gray-400"><?php echo e($registration->created_at->format('H:i')); ?></span>
                                <span class="text-xs text-gray-400 mt-1">
                                    <?php echo e($registration->created_at->diffForHumans()); ?>

                                </span>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <?php if($registration->status == 'pending'): ?>
                                <div class="flex flex-col space-y-2">
                                    <form action="<?php echo e(route('admin.registrations.updateStatus', $registration->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" 
                                                class="w-full bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-green-700 transition duration-200 flex items-center justify-center font-medium shadow-md shadow-green-500/20"
                                                onclick="return confirm('Approve this registration?')">
                                            <i class="fas fa-check mr-1 text-xs"></i> Approve
                                        </button>
                                    </form>
                                    
                                    <form action="<?php echo e(route('admin.registrations.updateStatus', $registration->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="rejected">
                                        <button type="submit" 
                                                class="w-full bg-red-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-red-700 transition duration-200 flex items-center justify-center font-medium shadow-md shadow-red-500/20"
                                                onclick="return confirm('Reject this registration?')">
                                            <i class="fas fa-times mr-1 text-xs"></i> Reject
                                        </button>
                                    </form>
                                    
                                    <button onclick="showDetails(<?php echo e($registration->id); ?>)" 
                                            class="w-full lux-button px-3 py-1.5 rounded-lg text-sm hover:bg-amber-700 transition duration-200 flex items-center justify-center font-medium shadow-md shadow-amber-500/20">
                                        <i class="fas fa-eye mr-1 text-xs"></i> Review
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="text-center text-gray-500 text-sm py-2">
                                    <i class="fas fa-check-circle text-green-500 text-lg mb-1"></i>
                                    <div>Processed</div>
                                </div>
                                
                                <button onclick="showDetails(<?php echo e($registration->id); ?>)" 
                                        class="w-full bg-gray-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-gray-700 transition duration-200 flex items-center justify-center font-medium shadow-md shadow-gray-500/20 mt-2">
                                    <i class="fas fa-eye mr-1 text-xs"></i> View
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center py-12">
                <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <i class="fas fa-clipboard-list text-gray-400 text-3xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No registrations found</h3>
                <p class="text-gray-500 max-w-md mx-auto">
                    <?php if(request('status') && request('status') != 'all'): ?>
                        There are no <?php echo e(request('status')); ?> registrations at the moment.
                    <?php else: ?>
                        No registration requests have been submitted yet.
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>
    </div>

    <?php if($registrations->hasPages()): ?>
    <div class="px-5 py-4 border-t border-gray-100 bg-gray-50/50 rounded-b-lg">
        <div class="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div class="text-sm text-gray-700 font-medium">
                Showing **<?php echo e($registrations->firstItem()); ?>** to **<?php echo e($registrations->lastItem()); ?>** of **<?php echo e($registrations->total()); ?>** results
            </div>
            <div class="flex space-x-1.5">
                <?php if($registrations->onFirstPage()): ?>
                    <span class="px-3 py-1 rounded-lg border border-gray-300 text-gray-400 cursor-not-allowed text-sm">
                        <i class="fas fa-angle-left"></i> Previous
                    </span>
                <?php else: ?>
                    <a href="<?php echo e($registrations->previousPageUrl()); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium">
                        <i class="fas fa-angle-left"></i> Previous
                    </a>
                <?php endif; ?>

                <?php
                    $currentPage = $registrations->currentPage();
                    $lastPage = $registrations->lastPage();
                    $start = max(1, $currentPage - 1);
                    $end = min($lastPage, $currentPage + 1);
                ?>

                <?php if($start > 1): ?>
                    <a href="<?php echo e($registrations->url(1)); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium">1</a>
                    <?php if($start > 2): ?>
                        <span class="px-3 py-1 text-gray-500">...</span>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page == $currentPage): ?>
                        <span class="px-3 py-1 rounded-lg border bg-amber-600 text-white text-sm font-medium"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($registrations->url($page)); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if($end < $lastPage): ?>
                    <?php if($end < $lastPage - 1): ?>
                        <span class="px-3 py-1 text-gray-500">...</span>
                    <?php endif; ?>
                    <a href="<?php echo e($registrations->url($lastPage)); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium"><?php echo e($lastPage); ?></a>
                <?php endif; ?>

                <?php if($registrations->hasMorePages()): ?>
                    <a href="<?php echo e($registrations->nextPageUrl()); ?>" class="px-3 py-1 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition duration-200 text-sm font-medium">
                        Next <i class="fas fa-angle-right"></i>
                    </a>
                <?php else: ?>
                    <span class="px-3 py-1 rounded-lg border border-gray-300 text-gray-400 cursor-not-allowed text-sm">
                        Next <i class="fas fa-angle-right"></i>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Registration Details Modal -->
<dialog id="detailsModal" class="modal-lux bg-white w-full max-w-2xl max-h-[90vh] overflow-hidden">
    <div class="flex justify-between items-center p-6 border-b border-gray-200 bg-gray-50 rounded-t-xl">
        <h3 class="text-lg font-semibold text-gray-800">Registration Details</h3>
        <button onclick="closeDetailsModal()" class="text-gray-400 hover:text-gray-600 transition duration-200">
            <i class="fas fa-times text-lg"></i>
        </button>
    </div>
    
    <div class="p-6 overflow-y-auto max-h-[60vh]" id="modalContent">
        <!-- Content will be loaded via AJAX -->
    </div>
    
    <div class="flex justify-end space-x-3 p-6 border-t border-gray-200 bg-gray-50 rounded-b-xl">
        <button type="button" onclick="closeDetailsModal()" 
                class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition duration-200 font-medium">
            Close
        </button>
    </div>
</dialog>

<script>
// Filter registrations by status
function filterRegistrations(status) {
    const url = new URL(window.location.href);
    if (status === 'all') {
        url.searchParams.delete('status');
    } else {
        url.searchParams.set('status', status);
    }
    window.location.href = url.toString();
}

// Search functionality
document.getElementById('searchInput').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.registration-row');
    
    rows.forEach(row => {
        const userName = row.getAttribute('data-user');
        const ukmName = row.getAttribute('data-ukm');
        
        if (userName.includes(searchTerm) || ukmName.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Show registration details
function showDetails(registrationId) {
    fetch(`/admin/registrations/${registrationId}/details`)
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalContent').innerHTML = html;
            document.getElementById('detailsModal').showModal();
        })
        .catch(error => {
            console.error('Error loading details:', error);
            document.getElementById('modalContent').innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-exclamation-triangle text-yellow-500 text-4xl mb-4"></i>
                    <p class="text-gray-600">Failed to load registration details.</p>
                </div>
            `;
            document.getElementById('detailsModal').showModal();
        });
}

function closeDetailsModal() {
    document.getElementById('detailsModal').close();
}

// Auto-close flash messages
setTimeout(() => {
    const flashMessages = document.querySelectorAll('.fixed');
    flashMessages.forEach(msg => msg.remove());
}, 5000);

// Close modal on backdrop click
document.getElementById('detailsModal').addEventListener('click', function(e) {
    if (e.target === this) closeDetailsModal();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/admin/registrations/index.blade.php ENDPATH**/ ?>