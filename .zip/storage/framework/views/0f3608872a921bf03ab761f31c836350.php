

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Manage Staff</h1>
</div>

<!-- Assign Staff Form -->
<div class="bg-white rounded shadow mb-6">
    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">Assign Staff to UKM</h2>
    </div>
    <div class="p-4">
        <form action="<?php echo e(route('admin.staff.assign')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Staff User</label>
                    <select name="user_id" required class="w-full border rounded px-3 py-2">
                        <option value="">Select Staff</option>
                        <?php $__currentLoopData = $staffUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">UKM</label>
                    <select name="ukm_id" required class="w-full border rounded px-3 py-2">
                        <option value="">Select UKM</option>
                        <?php $__currentLoopData = $ukms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ukm->id); ?>"><?php echo e($ukm->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    Assign Staff
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Staff Assignments Table -->
<div class="bg-white rounded shadow">
    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">Staff Assignments</h2>
    </div>
    <div class="p-4">
        <?php if($ukmStaff->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="p-2 text-left">Staff Name</th>
                            <th class="p-2 text-left">Email</th>
                            <th class="p-2 text-left">UKM</th>
                            <th class="p-2 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ukmStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="p-2"><?php echo e($assignment->user->name); ?></td>
                            <td class="p-2"><?php echo e($assignment->user->email); ?></td>
                            <td class="p-2"><?php echo e($assignment->ukm->name); ?></td>
                            <td class="p-2">
                                <form action="<?php echo e(route('admin.staff.remove', $assignment->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                                            onclick="return confirm('Remove this staff from UKM?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No staff assignments yet.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/admin/staff/index.blade.php ENDPATH**/ ?>