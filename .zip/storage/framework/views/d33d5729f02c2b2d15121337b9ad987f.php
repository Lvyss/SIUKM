

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-2xl font-bold">Manage Registrations</h1>
</div>

<!-- Registrations Table -->
<div class="bg-white rounded shadow">
    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">All Registrations</h2>
    </div>
    <div class="p-4">
        <?php if($registrations->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="p-2 text-left">User</th>
                            <th class="p-2 text-left">UKM</th>
                            <th class="p-2 text-left">Motivation</th>
                            <th class="p-2 text-left">Status</th>
                            <th class="p-2 text-left">Date</th>
                            <th class="p-2 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="p-2">
                                <div class="font-semibold"><?php echo e($registration->user->name); ?></div>
                                <div class="text-sm text-gray-600"><?php echo e($registration->user->email); ?></div>
                            </td>
                            <td class="p-2"><?php echo e($registration->ukm->name); ?></td>
                            <td class="p-2">
                                <div class="text-sm"><?php echo e(Str::limit($registration->motivation, 50)); ?></div>
                            </td>
                            <td class="p-2">
                                <span class="px-2 py-1 rounded text-xs 
                                    <?php echo e($registration->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                    <?php echo e($registration->status == 'approved' ? 'bg-green-100 text-green-800' : ''); ?>

                                    <?php echo e($registration->status == 'rejected' ? 'bg-red-100 text-red-800' : ''); ?>">
                                    <?php echo e($registration->status); ?>

                                </span>
                            </td>
                            <td class="p-2"><?php echo e($registration->created_at->format('d M Y')); ?></td>
                            <td class="p-2">
                                <?php if($registration->status == 'pending'): ?>
                                    <form action="<?php echo e(route('admin.registrations.updateStatus', $registration->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 mr-1">
                                            Approve
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('admin.registrations.updateStatus', $registration->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="rejected">
                                        <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600">
                                            Reject
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-gray-500 text-sm">Processed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No registrations yet.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/admin/registrations/index.blade.php ENDPATH**/ ?>