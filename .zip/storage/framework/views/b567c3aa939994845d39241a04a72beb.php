

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-2xl font-bold">Dashboard Admin</h1>
</div>

<!-- Stats -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="bg-white p-6 rounded shadow">
        <div class="flex items-center">
            <div class="p-3 bg-blue-100 rounded">
                <i class="fas fa-users text-blue-600 text-xl"></i>
            </div>
            <div class="ml-4">
                <h3 class="text-lg font-semibold"><?php echo e($stats['total_users']); ?></h3>
                <p class="text-gray-600">Total Users</p>
            </div>
        </div>
    </div>
    
    <div class="bg-white p-6 rounded shadow">
        <div class="flex items-center">
            <div class="p-3 bg-green-100 rounded">
                <i class="fas fa-user-tie text-green-600 text-xl"></i>
            </div>
            <div class="ml-4">
                <h3 class="text-lg font-semibold"><?php echo e($stats['total_staff']); ?></h3>
                <p class="text-gray-600">Total Staff</p>
            </div>
        </div>
    </div>
    
    <div class="bg-white p-6 rounded shadow">
        <div class="flex items-center">
            <div class="p-3 bg-purple-100 rounded">
                <i class="fas fa-clipboard-list text-purple-600 text-xl"></i>
            </div>
            <div class="ml-4">
                <h3 class="text-lg font-semibold"><?php echo e($stats['pending_registrations']); ?></h3>
                <p class="text-gray-600">Pending Registrations</p>
            </div>
        </div>
    </div>
</div>

<!-- Recent Registrations -->
<div class="bg-white rounded shadow mb-6">
    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">Recent Registrations</h2>
    </div>
    <div class="p-4">
        <?php if($recentRegistrations->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="p-2 text-left">User</th>
                            <th class="p-2 text-left">UKM</th>
                            <th class="p-2 text-left">Status</th>
                            <th class="p-2 text-left">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentRegistrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="p-2"><?php echo e($registration->user->name); ?></td>
                            <td class="p-2"><?php echo e($registration->ukm->name); ?></td>
                            <td class="p-2">
                                <span class="px-2 py-1 rounded text-xs 
                                    <?php echo e($registration->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                    <?php echo e($registration->status == 'approved' ? 'bg-green-100 text-green-800' : ''); ?>

                                    <?php echo e($registration->status == 'rejected' ? 'bg-red-100 text-red-800' : ''); ?>">
                                    <?php echo e($registration->status); ?>

                                </span>
                            </td>
                            <td class="p-2"><?php echo e($registration->created_at->format('d M Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No registrations yet.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Recent Users -->
<div class="bg-white rounded shadow">
    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">Recent Users</h2>
    </div>
    <div class="p-4">
        <?php if($recentUsers->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="p-2 text-left">Name</th>
                            <th class="p-2 text-left">Email</th>
                            <th class="p-2 text-left">Role</th>
                            <th class="p-2 text-left">Joined</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="p-2"><?php echo e($user->name); ?></td>
                            <td class="p-2"><?php echo e($user->email); ?></td>
                            <td class="p-2">
                                <span class="px-2 py-1 rounded text-xs 
                                    <?php echo e($user->role == 'admin' ? 'bg-red-100 text-red-800' : ''); ?>

                                    <?php echo e($user->role == 'staff' ? 'bg-blue-100 text-blue-800' : ''); ?>

                                    <?php echo e($user->role == 'user' ? 'bg-gray-100 text-gray-800' : ''); ?>">
                                    <?php echo e($user->role); ?>

                                </span>
                            </td>
                            <td class="p-2"><?php echo e($user->created_at->format('d M Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No users yet.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>