

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Manage Feeds</h1>
    <a href="<?php echo e(route('staff.feeds.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        <i class="fas fa-plus mr-2"></i>Add Feed
    </a>
</div>

<!-- Feeds Table -->
<div class="bg-white rounded shadow">
    <div class="p-4 border-b">
        <h2 class="text-lg font-semibold">All Feeds</h2>
    </div>
    <div class="p-4">
        <?php if($feeds->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="p-2 text-left">Image</th>
                            <th class="p-2 text-left">Feed</th>
                            <th class="p-2 text-left">UKM</th>
                            <th class="p-2 text-left">Content</th>
                            <th class="p-2 text-left">Date</th>
                            <th class="p-2 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $feeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="p-2">
                                <?php if($feed->image): ?>
                                    <img src="<?php echo e($feed->image); ?>" alt="<?php echo e($feed->title); ?>" class="w-12 h-12 rounded object-cover">
                                <?php else: ?>
                                    <div class="w-12 h-12 bg-gray-200 rounded flex items-center justify-center">
                                        <i class="fas fa-newspaper text-gray-400"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="p-2">
                                <div class="font-semibold"><?php echo e($feed->title); ?></div>
                            </td>
                            <td class="p-2"><?php echo e($feed->ukm->name); ?></td>
                            <td class="p-2">
                                <div class="text-sm text-gray-600"><?php echo e(Str::limit($feed->content, 50)); ?></div>
                            </td>
                            <td class="p-2"><?php echo e($feed->created_at->format('d M Y')); ?></td>
                            <td class="p-2">
                                <a href="<?php echo e(route('staff.feeds.edit', $feed->id)); ?>" 
                                   class="bg-yellow-500 text-white px-3 py-1 rounded text-sm hover:bg-yellow-600 mr-2 inline-block">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('staff.feeds.destroy', $feed->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                                            onclick="return confirm('Delete this feed?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-8">
                <i class="fas fa-newspaper text-gray-400 text-6xl mb-4"></i>
                <h3 class="text-lg font-semibold text-gray-600">No Feeds Yet</h3>
                <p class="text-gray-500">Create your first feed to share updates.</p>
                <a href="<?php echo e(route('staff.feeds.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 inline-block mt-4">
                    <i class="fas fa-plus mr-2"></i>Create Feed
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/staff/feeds/index.blade.php ENDPATH**/ ?>