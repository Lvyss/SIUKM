

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">My Profile</h1>
        <p class="text-gray-600">Kelola informasi profil Anda</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Profile Information -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Personal Information</h2>
                
                <form action="<?php echo e(route('user.profile.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">Full Name</label>
                            <input type="text" name="name" value="<?php echo e($user->name); ?>" 
                                   class="w-full border rounded px-3 py-2" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">Email</label>
                            <input type="email" value="<?php echo e($user->email); ?>" 
                                   class="w-full border rounded px-3 py-2 bg-gray-100" disabled>
                            <p class="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">Phone Number</label>
                            <input type="text" name="phone" value="<?php echo e($user->phone); ?>" 
                                   class="w-full border rounded px-3 py-2" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">NIM</label>
                            <input type="text" value="<?php echo e($user->nim); ?>" 
                                   class="w-full border rounded px-3 py-2 bg-gray-100" disabled>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                            <label class="block text-sm font-medium mb-1">Fakultas</label>
                            <input type="text" name="fakultas" value="<?php echo e($user->fakultas); ?>" 
                                   class="w-full border rounded px-3 py-2" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">Jurusan</label>
                            <input type="text" name="jurusan" value="<?php echo e($user->jurusan); ?>" 
                                   class="w-full border rounded px-3 py-2" required>
                        </div>
                    </div>
                    
                    <div class="flex justify-end">
                        <button type="submit" 
                                class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 font-semibold">
                            Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- UKM Registrations -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">My UKM Registrations</h2>
            
            <?php if($registrations->count() > 0): ?>
                <div class="space-y-3">
                    <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-3 border rounded-lg">
                        <div class="flex justify-between items-start mb-2">
                            <h3 class="font-semibold"><?php echo e($registration->ukm->name); ?></h3>
                            <span class="px-2 py-1 rounded-full text-xs font-medium
                                <?php echo e($registration->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                <?php echo e($registration->status == 'approved' ? 'bg-green-100 text-green-800' : ''); ?>

                                <?php echo e($registration->status == 'rejected' ? 'bg-red-100 text-red-800' : ''); ?>">
                                <?php echo e($registration->status); ?>

                            </span>
                        </div>
                        
                        <p class="text-sm text-gray-600 mb-2">
                            Applied: <?php echo e($registration->created_at->format('d M Y')); ?>

                        </p>
                        
                        <?php if($registration->approved_at): ?>
                        <p class="text-sm text-gray-600">
                            Processed: <?php echo e($registration->approved_at->format('d M Y')); ?>

                        </p>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="text-center py-8">
                    <i class="fas fa-users text-gray-400 text-4xl mb-3"></i>
                    <p class="text-gray-600">No UKM registrations yet.</p>
                    <a href="<?php echo e(route('user.ukm.list')); ?>" class="text-blue-600 hover:text-blue-700 text-sm mt-2 inline-block">
                        Browse UKM →
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar\proyek\jawa_react\Siukm\resources\views/user/profile.blade.php ENDPATH**/ ?>