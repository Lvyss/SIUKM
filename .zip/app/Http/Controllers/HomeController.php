<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ukm;
use App\Models\Event;
use App\Models\Feed;

class HomeController extends Controller
{
    // Welcome Page (Guest)
    public function welcome()
    {
        return view('welcome');
    }

    // About Page
    public function about()
    {
        return view('about');
    }

    // Dashboard berdasarkan role
public function dashboard()
{
    $user = auth()->user();
    
    if ($user->isAdmin()) {
        return redirect()->route('admin.dashboard');
    } elseif ($user->isStaff()) {
        return redirect()->route('staff.dashboard');
    } else {
        return redirect()->route('user.dashboard');
    }
}
}