<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI-UKM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
    margin: 0;
    padding: 0;
    border: 0;
    box-sizing: border-box;
}

        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .line-clamp-1 { overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1; }
        .line-clamp-2 { overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
        .line-clamp-3 { overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3; }
        .line-clamp-4 { overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 4; }
    </style>
</head>
<body class="bg-gray-50 font-sans text-gray-800">
    <!-- Navigation -->
<nav class="bg-white border-b shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-24">
        <div class="flex justify-between items-center h-16">
            <!-- Logo -->
            <div class="flex items-center">
                <div class="text-blue-600">
                    <span class="text-3xl font-extrabold">SIUKM</span>
                </div>
            </div>

            <!-- Menu Items -->
            <div class="flex items-center space-x-6">
                <a href="{{ route('user.dashboard') }}" class="text-[13px]  text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200">
                    Home
                </a>
                <a href="{{ route('user.feeds.index') }}" class="text-[13px] text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200">
                    Feed
                </a>
                <a href="{{ route('user.events.index') }}" class="text-[13px] text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200">
                    Event
                </a>
                <a href="{{ route('user.ukm.list') }}" class="text-[13px] text-gray-600 hover:text-blue-600 font-medium transition-colors duration-200">
                    UKM
                </a>
                
                <!-- Icons -->
                <div class="flex items-center space-x-4 ml-4">
                    {{-- <!-- Search Icon -->
                    <button class="text-gray-500 hover:text-blue-600 transition-colors duration-200">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </button> --}}
                    
                    <!-- Profile Dropdown -->
                    <div class="relative mt-2">
                        <button class="text-gray-500 hover:text-blue-600 transition-colors duration-200 focus:outline-none">
                            <svg class="w-5 h-5 " fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                        </button>
                        
                        <!-- Dropdown Menu -->
                        <div class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 opacity-0 invisible transition-all duration-200 transform translate-y-2 group-hover:opacity-100 group-hover:visible group-hover:translate-y-0">
                            <div class="px-4 py-2 border-b border-gray-100">
                                <p class="text-sm font-medium text-gray-900">{{ auth()->user()->name }}</p>
                                <p class="text-xs text-gray-500 truncate">{{ auth()->user()->email }}</p>
                            </div>
                            <a href="{{ route('user.profile') }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-200">
                                My Profile
                            </a>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-200">
                                    Logout
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

<style>
    /* Pastiin group hover work */
    .relative:hover .absolute {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
    }
</style>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto ">
        @yield('content')
    </main>

    <!-- Footer -->
 <footer class="bg-gradient-to-br from-gray-700 to-black border-t mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-4 md:mb-0">
                    <div class="font-bold text-xl text-blue-600">
                        <span class="text-2xl font-extrabold">SIUKM</span>
                    </div>
                    <p class="text-gray-600 text-sm mt-2">Sistem Informasi Unit Kegiatan Mahasiswa</p>
                </div>
                <div class="flex space-x-6">
                    <a href="#" class="text-gray-400 hover:text-blue-600">
                        <i class="fab fa-instagram text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-blue-600">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-blue-600">
                        <i class="fab fa-facebook text-xl"></i>
                    </a>
                </div>
            </div>
            <div class="border-t mt-6 pt-6 text-center">
                <p class="text-gray-500 text-sm">&copy; 2024 SIUKM. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Flash Messages -->
    @if(session('success'))
        <div class="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                <span>{{ session('success') }}</span>
            </div>
        </div>
    @endif

    @if(session('error'))
        <div class="fixed top-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span>{{ session('error') }}</span>
            </div>
        </div>
    @endif

    <script>
        // Auto hide flash messages
        setTimeout(() => {
            const messages = document.querySelectorAll('.fixed');
            messages.forEach(msg => {
                if (msg.classList.contains('bg-green-500') || msg.classList.contains('bg-red-500')) {
                    msg.remove();
                }
            });
        }, 5000);

        // Dropdown menu functionality
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.group')) {
                const dropdowns = document.querySelectorAll('.group-hover\\:block');
                dropdowns.forEach(el => {
                    el.classList.add('hidden');
                });
            }
        });

        // Keep dropdown open on hover
        const profileGroup = document.querySelector('.group');
        if (profileGroup) {
            profileGroup.addEventListener('mouseenter', () => {
                const dropdown = profileGroup.querySelector('.hidden');
                if (dropdown) {
                    dropdown.classList.remove('hidden');
                }
            });
            
            profileGroup.addEventListener('mouseleave', () => {
                const dropdown = profileGroup.querySelector('.group-hover\\:block');
                if (dropdown) {
                    dropdown.classList.add('hidden');
                }
            });
        }
    </script>

    @yield('scripts')
</body>
</html>